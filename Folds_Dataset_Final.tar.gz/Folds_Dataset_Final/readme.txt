This dataset was downloaded from http://sites.ecomp.uefs.br/lasic/projetos/libras-dataset

The dataset is free to use for scientific research. The citation paper for this dataset is

I. L. O. Bastos, M. F. Angelo and A. C. Loula, "Recognition of Static Gestures Applied to Brazilian Sign Language (Libras)," 2015 28th SIBGRAPI Conference on Graphics, Patterns and Images, Salvador, 2015, pp. 305-312.


If you use this dataset, cite the paper reference, not this website.

Please refer to the website for further information.